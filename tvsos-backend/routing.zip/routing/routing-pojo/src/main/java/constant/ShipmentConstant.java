package constant;
public class ShipmentConstant {
    public static final Integer TASK_WEIGHT_LIMIT = 2000;    // 单个任务重量上限
    public static final Integer SHIPMENT_BATCH_SIZE = 20;    // 每次拆分订单数量
    public static final Integer SCHEDULE_MINUTE = 2;         // 定时任务间隔分钟
}