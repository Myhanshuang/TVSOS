package dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PoiQueryDTO {
    private String name;
    private Integer tybe;
    private Integer status;
}
