package com.tvsos.mapper;

import entity.OrderDetail;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;

@Mapper
public interface OrderDetailMapper {
    void insert(OrderDetail orderDetail);
    List<OrderDetail> findByTransportOrderId(Long transportOrderId);

}