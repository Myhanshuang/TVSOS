package com.tvsos.service;

public interface OrderSplitterService {
    /**
     * 查找所有“待处理”的总订单 (TransportOrder)，
     * 并将它们拆分为适合车辆装载的“可调度”子任务 (OrderDetail)。
     */
    void splitUnprocessedOrders();
}