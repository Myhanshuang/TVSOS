package com.tvsos.mapper;

import entity.Assign;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AssignMapper {
    void insert(Assign assign);
}